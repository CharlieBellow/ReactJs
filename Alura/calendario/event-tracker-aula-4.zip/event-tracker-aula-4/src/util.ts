let id = 0;

export const obterId = () : number => {
  return id++;
}