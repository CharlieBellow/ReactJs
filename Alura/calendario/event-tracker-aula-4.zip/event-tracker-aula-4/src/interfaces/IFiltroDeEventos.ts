export interface IFiltroDeEventos {
  data?: Date | null
}