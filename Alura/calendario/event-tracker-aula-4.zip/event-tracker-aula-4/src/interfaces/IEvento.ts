export interface IEvento {
  id?: number
  descricao: string
  completo: boolean
  inicio: Date
  fim: Date
}